package com.example.myapplication6
import android.app.AlertDialog

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.snackbar.Snackbar

class Main4Activity : AppCompatActivity() {
    lateinit var checkboxToast:CheckBox
    lateinit var checkboxSnack:CheckBox
    lateinit var checkboxAlert:CheckBox
    lateinit var clickme:Button
    lateinit var main:ConstraintLayout








    override fun onCreate(savedInstanceState: Bundle?) {



        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main4)
        checkboxToast = findViewById(R.id.toastmsg2)
        checkboxSnack=findViewById(R.id.snackbox)
        checkboxAlert=findViewById(R.id.alertdialouge)
        clickme=findViewById(R.id.clickme1)
        main=findViewById(R.id.main)

        clickme.setOnClickListener {
            if(checkboxToast.isChecked){
                Toast.makeText(applicationContext,"This is a toast message",Toast.LENGTH_LONG).show()
            }
            else if(checkboxSnack.isChecked){
                Snackbar.make(main,"This is message",Snackbar.LENGTH_LONG).setAction("no",{}).show()

            }
            else{
                val alertDialogBuilder = AlertDialog.Builder(this)
                alertDialogBuilder.setMessage("This is an alert dialog message")
                alertDialogBuilder.setPositiveButton("OK") { dialog, _ ->
                    dialog.dismiss()
                }

                val alertDialog = alertDialogBuilder.create()
                alertDialog.show()


            }
        }






        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}