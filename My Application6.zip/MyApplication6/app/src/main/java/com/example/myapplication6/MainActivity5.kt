package com.example.myapplication6

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity5 : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    lateinit var textbox: TextView
    lateinit var spinner: Spinner
    var countries = arrayOf("Nepal", "USA", "Russia", "India")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main5)

        textbox = findViewById(R.id.textView1)
        spinner = findViewById(R.id.spinner1)
        val adapter = ArrayAdapter(this@MainActivity5, android.R.layout.simple_spinner_item, countries)
        spinner.adapter = adapter
        spinner.onItemSelectedListener = this
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        textbox.text = countries[position]
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        // Handle when nothing is selected
    }
}
