package com.example.myapplication6

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.snackbar.Snackbar


class MainActivity6 : AppCompatActivity() {

    lateinit var textview:AutoCompleteTextView
    lateinit var Searchbtn:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        setContentView(R.layout.activity_main6)

        var data= arrayOf("Nepal","USA","Russia","India")

        textview=findViewById(R.id.searchview)
        Searchbtn=findViewById(R.id.searchbtn)

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val autoComplete_adapter=ArrayAdapter(this,android.R.layout.simple_dropdown_item_1line,data)
        textview.setAdapter(autoComplete_adapter)
        textview.threshold=1


        Searchbtn.setOnClickListener {
            val selectedText = textview.text.toString()
            val snack = Snackbar.make(findViewById(android.R.id.content), selectedText, Snackbar.LENGTH_LONG)
            if(selectedText.isEmpty()){
                val snack1 = Snackbar.make(findViewById(android.R.id.content), "You haven't selected any items", Snackbar.LENGTH_LONG)
                snack1.show()



            }
            else{
                snack.show()


            }
        }



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}