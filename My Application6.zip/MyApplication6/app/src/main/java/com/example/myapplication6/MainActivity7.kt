package com.example.myapplication6

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.Button
import android.widget.DatePicker
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Calendar

class MainActivity7 : AppCompatActivity() {

    lateinit var button1:Button
    lateinit var Text1:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main7)

        button1=findViewById(R.id.btncal)
        Text1=findViewById(R.id.caltext)

        button1.setOnClickListener {
            loadCalender()
        }

    }

    private fun loadCalender() {
        var c = Calendar.getInstance()
        var year_=c.get(Calendar.YEAR)
        var month_=c.get(Calendar.MONTH)
        var day_=c.get(Calendar.DAY_OF_MONTH)

        var dateDialog=DatePickerDialog(this,DatePickerDialog.OnDateSetListener{view: DatePicker?, year: Int, month: Int, dayOfMonth: Int -> Text1.text="$year/$month/$dayOfMonth"  }
        ,year_,month_,day_)
        dateDialog.show()


}}