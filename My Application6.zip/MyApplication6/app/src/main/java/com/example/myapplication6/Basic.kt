



package com.example.myapplication6
fun main() {
//    println("hello world")
//
//
//    val a:Double=10.26;
//    print(a.toInt())
//    print(a.toByte())
var aayush:String="Jay hanuman";
    var i:Int=aayush.length
    println(i)

    var isEqual:Boolean=aayush.equals("dadadada")
    println(isEqual)



    var a:String="sasasasa";
    var b:String="sa   sasasa";
    println(a.uppercase())
    println(a.lowercase())
    println(a.trim())
    println(b.replace("","%5"))
    println(aayush.plus(a))
    println("this is a ${a} ")





}




