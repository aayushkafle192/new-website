package com.example.myapplication6

//

//fun main(args: Array<String>) {
//    var data=mapOf(
//
//        "Nepal " to "landlocked country",
//        "Apple" to "iphone",
//        "Android" to "OS"
//
//    )
//    var word: String=readln()
//    var result:String=data[word].toString()
//
//    println("The meaning of $word is $result")
//}
//
//
//
//




