package com.example.myapplication6

import android.os.Bundle
import android.widget.ImageView
import android.widget.RadioButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    lateinit var radioButtondenim:RadioButton
    lateinit var radioButtondevils:RadioButton
    lateinit var radioButtontshirt:RadioButton
    lateinit var imageView: ImageView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        radioButtondenim=findViewById(R.id.radioButtondenim)
        radioButtondevils=findViewById(R.id.radioButtondevils)
        radioButtontshirt=findViewById(R.id.radioButtontshirt)
        imageView=findViewById(R.id.imageView)


        radioButtondenim.setOnClickListener {
            imageView.setImageResource(R.drawable.denim)
        }

        radioButtondevils.setOnClickListener {
            imageView.setImageResource(R.drawable.devils)
        }
        radioButtontshirt.setOnClickListener {
            imageView.setImageResource((R.drawable.round))
        }

    }
}

