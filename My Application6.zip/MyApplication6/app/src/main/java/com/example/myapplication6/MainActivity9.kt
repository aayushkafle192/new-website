package com.example.myapplication6

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.DatePicker
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.w3c.dom.Text
import java.util.Calendar

class MainActivity9() : AppCompatActivity(),AdapterView.OnItemSelectedListener {
    var data= arrayOf("Bhaktapur","Kathmandu","Lalitpur","Banesehwor")
    lateinit var location:TextView
    lateinit var spinner:Spinner
    lateinit var button1: Button
    lateinit var Text1:TextView
    lateinit var button2:Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main9)


        location=findViewById(R.id.locationview)
        spinner=findViewById(R.id.spinner3)
        spinner.onItemSelectedListener=this
        var arrayAdapter=ArrayAdapter(this,android.R.layout.simple_spinner_item,data)
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = arrayAdapter
        button1=findViewById(R.id.btncal1)
        Text1=findViewById(R.id.caltext1)
        button2=findViewById(R.id.loginbtn)

        button1.setOnClickListener {
            loadCalender()
        }
        button2.setOnClickListener {
            // Create an AlertDialog.Builder
            val builder = AlertDialog.Builder(this)

            // Set the alert dialog title and message
            builder.setTitle("Success")
            builder.setMessage("Successfully logged in")

            // Set a positive button and its click listener
            builder.setPositiveButton("OK") { dialog, _ ->
                // Dismiss the dialog when OK button is clicked
                dialog.dismiss()
            }

            // Create and show the AlertDialog
            val dialog = builder.create()
            dialog.show()
        }
    }













    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        if(parent !=null){
            location.text = parent.getItemAtPosition(position).toString()

        }

    }

    override fun onNothingSelected(parent: AdapterView<*>?) {

    }
    private fun loadCalender() {
        var c = Calendar.getInstance()
        var year_=c.get(Calendar.YEAR)
        var month_=c.get(Calendar.MONTH)
        var day_=c.get(Calendar.DAY_OF_MONTH)

        var dateDialog= DatePickerDialog(this,
            DatePickerDialog.OnDateSetListener{ view: DatePicker?, year: Int, month: Int, dayOfMonth: Int -> Text1.text="$year/$month/$dayOfMonth"  }
            ,year_,month_,day_)
        dateDialog.show()
    }
}


